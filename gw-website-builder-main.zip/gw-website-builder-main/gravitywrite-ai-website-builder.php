<?php

/**
 * Plugin Name: AI Website Builder - Gravity Write
 * Plugin URI: https://gravitywrite.com/ai-website-builder
 * Description: Create stunning websites quickly with AI Website Builder by Gravity Write. Utilize our templates and AI tools for a streamlined workflow, perfect for designers and developers.
 * Version: 1.0.0
 * Author: Gravity Write
 * Author URI: https://gravitywrite.com/
 */

// Hook to modify the plugin meta links
add_filter('plugin_row_meta', 'gravitywrite_plugin_row_meta', 10, 2);

function gravitywrite_plugin_row_meta($plugin_meta, $plugin_file) {
    // Check if the plugin is the AI Website Builder - Gravity Write plugin
    if ( strpos($plugin_file, 'ai-website-builder') !== false ) {
        // Modify the "View Plugin Site" to "View Details"
        $plugin_meta = array_map(function($link) {
            if (strpos($link, 'Visit plugin site') !== false) {
                // Replace "View Plugin Site" link with "View Details"
                return '<a href="https://gravitywrite.com/ai-website-builder" target="_blank">' . __('View Details') . '</a>';
            }
            return $link;
        }, $plugin_meta);
    }

    return $plugin_meta;
}

add_filter( 'astra_disable_starter_templates_promotions', '__return_true' );
add_action( 'after_setup_theme',
   function() {
       // Check if the affiliate URL parameter has already been added.
       if ( ! get_option( 'astra_partner_url_param' ) ) {
           // Add the affiliate ID (replace 'YOUR-AFFILIATE-ID' with the actual ID).
           update_option( 'astra_partner_url_param', '346' );
       }
   }
);

// Add custom action links for the plugin on the plugins page.
function gravitywrite_add_plugin_action_links($links, $file) {
    $plugin_file = 'gw-website-builder-main/gravitywrite-ai-website-builder.php';
    
    if ($file === plugin_basename($plugin_file)) {
        $settings_link = '<a href="' . esc_url(admin_url('admin.php?page=gravitywrite_settings')) . '">Settings</a>';
        $builder_link = '<a href="' . esc_url(admin_url('admin.php?page=gw-website-builder')) . '">Build Website</a>';
        
        array_unshift($links, $settings_link, $builder_link);
    }
    
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'gravitywrite_add_plugin_action_links', 10, 2);


if (!defined('ABSPATH')) {
    exit;
}

require_once(ABSPATH . 'wp-admin/includes/class-wp-upgrader.php');
require_once(ABSPATH . 'wp-admin/includes/plugin.php');
require_once(ABSPATH . 'wp-admin/includes/theme.php');
require_once(ABSPATH . 'wp-admin/includes/file.php');
require_once(ABSPATH . 'wp-admin/includes/post.php');
require_once(ABSPATH . 'wp-admin/includes/media.php');
require_once(ABSPATH . 'wp-admin/includes/image.php');
require_once(ABSPATH . 'wp-admin/includes/class-wp-ajax-upgrader-skin.php');
require_once(ABSPATH . 'wp-admin/includes/import.php');
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

// Imports
require_once plugin_dir_path(__FILE__) . 'includes/imports/import-posts.php';
require_once plugin_dir_path(__FILE__) . 'includes/imports/gravitywrite-wp-import.php';
require_once plugin_dir_path(__FILE__) . 'includes/imports/import-header-footer.php';
require_once plugin_dir_path(__FILE__) . 'includes/imports/import-menus.php';
// Installations
require_once plugin_dir_path(__FILE__) . 'includes/installations/install_theme.php';
require_once plugin_dir_path(__FILE__) . 'includes/installations/install_plugins.php';
// Integrations
require_once plugin_dir_path(__FILE__) . 'includes/integrations/elementor-import.php';
// Forms
require_once plugin_dir_path(__FILE__) . 'includes/forms/save-form-details.php';
// Menus
require_once plugin_dir_path(__FILE__) . 'includes/menus/create-menu.php';
// AI
require_once plugin_dir_path(__FILE__) . 'includes/ai/update-ai-content.php';
// Users
require_once plugin_dir_path(__FILE__) . 'includes/users/replace-user-details.php';
// Utilities
require_once plugin_dir_path(__FILE__) . 'includes/utilities/download-file.php';

//REST APIs
require_once plugin_dir_path(__FILE__) . 'API/api-functions.php';
require_once plugin_dir_path(__FILE__) . 'API/user-functions.php';



$plugins = [
    "elementor", 
    "elementskit-lite", 
    "jeg-elementor-kit", 
    "metform", 
    "header-footer-elementor"
];

update_option('custom_plugins_to_delete', json_encode($plugins));


function log_message($message, $log_file_path,$level, $api_url) {
    $timestamp = date('[Y-m-d H:i:s]');
    
    // Include the API URL in the log entry
    $log_entry = "$timestamp [$level] $message [API URL: $api_url]\n";

    error_log($log_entry, 3, $log_file_path);
}

register_activation_hook(__FILE__, function () {
    create_required_tables();

    // Get the current value of gravitywrite_account_key
    $current_value = get_option('gravitywrite_account_key');
    if (!empty($current_value)) {
        update_option('gravitywrite_account_key', $current_value);
    } else {
        update_option('gravitywrite_account_key', 'disconnected');
    }

    // Update memory limit
    update_wp_config_memory_limit('512M');

    // Set a transient to trigger the redirect
    set_transient('gw_plugin_activated', true, 30);
});

// Redirect after activation
add_action('admin_init', 'gw_plugin_redirect_after_activation');

function gw_plugin_redirect_after_activation() {
    // Check if the transient exists
    if (get_transient('gw_plugin_activated')) {
        // Delete the transient
        delete_transient('gw_plugin_activated');

        // Redirect to the desired page
        wp_redirect(admin_url('admin.php?page=gw-website-builder#/'));
        exit;
    }
}

function update_wp_config_memory_limit($new_limit = '512M') {
    $path_to_wp_config = ABSPATH . 'wp-config.php';
    $content = file_get_contents($path_to_wp_config);

    $pattern = "/define\(\s*'WP_MEMORY_LIMIT'\s*,\s*'.*?'\s*\);/";
    
    if (preg_match($pattern, $content)) {
        // If WP_MEMORY_LIMIT is already defined, replace it
        $replacement = "define('WP_MEMORY_LIMIT', '$new_limit');";
        $new_content = preg_replace($pattern, $replacement, $content);
    } else {
        // If not defined, add the definition just before "That's all, stop editing!"
        $marker = "/* That's all, stop editing! Happy publishing. */";
        $replacement = "define('WP_MEMORY_LIMIT', '$new_limit');\n" . $marker;
        $new_content = str_replace($marker, $replacement, $content);
    }

    // Write the changes back to wp-config.php
    if ($new_content !== $content) {
        if (is_writable($path_to_wp_config)) {
            file_put_contents($path_to_wp_config, $new_content);
            return true;
        } else {
            // Handle the error appropriately
            return false;
        }
    }
    return false; // No change needed
}



function create_required_tables() {
    global $wpdb;
    // Table for user form details
    $table_name1 = $wpdb->prefix . 'gw_user_form_details';  
    // Table for imported posts
    $table_name2 = $wpdb->prefix . 'imported_posts';  
    // Table for menu details
    $table_name3 = $wpdb->prefix . 'menu_details';  
    $table_name4 = $wpdb->prefix . 'menu_item_details';  
    $table_name5 = $wpdb->prefix . 'generated_content'; 
    $table_name6 = $wpdb->prefix . 'generated_html_content'; 
    $table_name7 = $wpdb->prefix . 'page_generation_status'; 
    $table_name8 = $wpdb->prefix . 'selected_template_data'; 
    $table_name9 = $wpdb->prefix . 'gw_user_plan_details'; 

    
    $charset_collate = $wpdb->get_charset_collate();

    $sql9 = "CREATE TABLE $table_name9 (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name varchar(100) NOT NULL,
        email varchar(100) NOT NULL,
        plan_detail text NOT NULL,
        gravator varchar(255) NOT NULL,
        website_used int(11) NOT NULL,
        website_total int(11) NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";



    // SQL to create the user form details table
    $sql1 = "CREATE TABLE $table_name1 (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        businessName text,
        description1 text,
        description2 text,
        images longtext, 
        designs longtext,  
        templateid mediumint(9),
        templatename text,
        logo text,
        category text, 
        content longtext, 
        color longtext, 
        font longtext,
        templateList longtext, 
        contactform longtext,
        lastStep longtext,
        defaultColor longtext,
        defaultFont longtext,
        templateColor longtext,
        templateFont longtext,
        PRIMARY KEY (id)
    ) $charset_collate;";

    // SQL to create the imported posts table
    $sql2 = "CREATE TABLE $table_name2 (
        post_id INT NOT NULL AUTO_INCREMENT,
        post_type VARCHAR(255),
        template_name VARCHAR(255),
        page_name VARCHAR(255),
        PRIMARY KEY (post_id)
    ) $charset_collate;";

    // SQL to create the menu details table
    $sql3 = "CREATE TABLE $table_name3 (
        menu_id INT NOT NULL AUTO_INCREMENT,
        menu_name VARCHAR(255),
        PRIMARY KEY (menu_id)
    ) $charset_collate;";
    $sql4 = "CREATE TABLE $table_name4 (
        menu_id INT NOT NULL AUTO_INCREMENT,
        menu_name VARCHAR(255),
        menu_item_order VARCHAR(255),
        PRIMARY KEY (menu_id)
    ) $charset_collate;";

$sql5 = "CREATE TABLE $table_name5 (
    id INT NOT NULL AUTO_INCREMENT,
    page_name VARCHAR(255) NOT NULL,
    template_name VARCHAR(255) NOT NULL,
    version_name VARCHAR(255) NOT NULL,
    json_content LONGTEXT NOT NULL,
    PRIMARY KEY (id)
) $charset_collate;";
$sql6 = "CREATE TABLE $table_name6 (
    id INT NOT NULL AUTO_INCREMENT,
    version_name VARCHAR(255),
    page_name VARCHAR(255),
    template_name VARCHAR(255),
    html_data LONGTEXT,
    PRIMARY KEY (id)
) $charset_collate;";
$sql7 = "CREATE TABLE $table_name7 (
    id INT NOT NULL AUTO_INCREMENT,
    page_name VARCHAR(255),
    page_status VARCHAR(255),
    page_slug VARCHAR(255),
    selected VARCHAR(255),
    PRIMARY KEY (id)
) $charset_collate;";
$sql8 = "CREATE TABLE $table_name8 (
    id INT NOT NULL,
    template_id VARCHAR(255),
    template_name VARCHAR(255),
    template_json_data LONGTEXT,
    PRIMARY KEY (id)
) $charset_collate;";

    // Check if the tables exist and create them if not
    if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name1}'") != $table_name1) {
        dbDelta($sql1);
    }
    if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name2}'") != $table_name2) {
        dbDelta($sql2);
    }
    if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name3}'") != $table_name3) {
        dbDelta($sql3);
    }
    if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name4}'") != $table_name4) {
        dbDelta($sql4);
    }
    if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name5}'") != $table_name5) {
        dbDelta($sql5);
    }
    if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name6}'") != $table_name6) {
        dbDelta($sql6);
    }
    if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name7}'") != $table_name7) {
        dbDelta($sql7);
    }
    if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name8}'") != $table_name8) {
        dbDelta($sql8);
    }
    if ($wpdb->get_var("SHOW TABLES LIKE '{$table_name9}'") != $table_name9) {
        dbDelta($sql9);
    }
}

function block_backbone_js_on_admin_page() {
    // Check if we are in the admin area and on the specific page
    if (is_admin() && isset($_GET['page']) && $_GET['page'] === 'gw-website-builder') {
        // Dequeue and deregister Backbone.js
        wp_dequeue_script('backbone');
        wp_deregister_script('backbone');
    }
}
add_action('admin_enqueue_scripts', 'block_backbone_js_on_admin_page', 20);


function add_custom_css_programmatically() {
    $existing_css = wp_get_custom_css();

    // Define the additional CSS you want to add
    $new_css = "
        .hfe-site-logo-set .hfe-site-logo-img {
            width: 150px; /* Set your desired width */
            max-width: 100%; /* Ensure responsiveness */
            height: auto; /* Maintain aspect ratio */
        }
    ";

    // Check if the new CSS is already included to avoid duplicates
    if (strpos($existing_css, trim($new_css)) === false) {
        // Append the new CSS to the existing CSS
        $updated_css = $existing_css . "\n" . $new_css;

        // Save the updated CSS back to the Customizer
        wp_update_custom_css_post($updated_css);
    }
}
//add_action('init', 'add_custom_css_programmatically');


function block_all_js_except_mainfile_on_admin_page() {
    // Check if we are in the admin area and on the specific page
    if (is_admin() && isset($_GET['page']) && $_GET['page'] === 'gw-website-builder') {

        global $wp_scripts;

        foreach ($wp_scripts->queue as $handle) {
            // Dequeue everything
            wp_dequeue_script($handle);
            wp_deregister_script($handle);
        }

        // Re-enqueue only 'mainfile.js'
        wp_enqueue_script(
            'mainfile', // Handle for the script
            plugin_dir_url(__FILE__) . 'API/dist/mainfile.js',
            array(), // Dependencies (leave empty if none)
            '1.0', // Version
            true // Load in the footer
        );

        
    }
}
add_action('admin_enqueue_scripts', 'block_all_js_except_mainfile_on_admin_page', 20);

function gw_add_posthog_script() {
    // Check if it's the specific admin page
    if (is_admin() && isset($_GET['page']) && $_GET['page'] === 'gw-website-builder') {
        ?>
        <script>
            !(function (t, e) {
                var o, n, p, r;
                e.__SV ||
                    ((window.posthog = e),
                    (e._i = []),
                    (e.init = function (i, s, a) {
                        function g(t, e) {
                            var o = e.split(".");
                            2 == o.length && ((t = t[o[0]]), (e = o[1])),
                                (t[e] = function () {
                                    t.push([e].concat(Array.prototype.slice.call(arguments, 0)));
                                });
                        }
                        ((p = t.createElement("script")).type = "text/javascript"),
                            (p.crossOrigin = "anonymous"),
                            (p.async = !0),
                            (p.src =
                                s.api_host.replace(".i.posthog.com", "-assets.i.posthog.com") +
                                "/static/array.js"),
                            (r = t.getElementsByTagName("script")[0]).parentNode.insertBefore(
                                p,
                                r
                            );
                        var u = e;
                        for (
                            void 0 !== a ? (u = e[a] = []) : (a = "posthog"),
                                u.people = u.people || [],
                                u.toString = function (t) {
                                    var e = "posthog";
                                    return (
                                        "posthog" !== a && (e += "." + a), t || (e += " (stub)"), e
                                    );
                                },
                                u.people.toString = function () {
                                    return u.toString(1) + ".people (stub)";
                                },
                                o =
                                    "init capture register register_once register_for_session unregister unregister_for_session getFeatureFlag getFeatureFlagPayload isFeatureEnabled reloadFeatureFlags updateEarlyAccessFeatureEnrollment getEarlyAccessFeatures on onFeatureFlags onSessionId getSurveys getActiveMatchingSurveys renderSurvey canRenderSurvey getNextSurveyStep identify setPersonProperties group resetGroups setPersonPropertiesForFlags resetPersonPropertiesForFlags setGroupPropertiesForFlags resetGroupPropertiesForFlags reset get_distinct_id getGroups get_session_id get_session_replay_url alias set_config startSessionRecording stopSessionRecording sessionRecordingStarted captureException loadToolbar get_property getSessionProperty createPersonProfile opt_in_capturing opt_out_capturing has_opted_in_capturing has_opted_out_capturing clear_opt_in_out_capturing debug".split(
                                        " "
                                    ),
                                n = 0;
                            n < o.length;
                            n++
                        )
                            g(u, o[n]);
                        e._i.push([i, s, a]);
                    }),
                    (e.__SV = 1));
            })(document, window.posthog || []);
            posthog.init("phc_b9dzdrKSxojTwWTqBEnaRv8QAB30Zfpd6LTteTX27ae", {
                api_host: "https://us.i.posthog.com",
            });
            
            console.log('PostHog script is running');

        </script>
        <?php
    }
}

add_action('admin_footer', 'gw_add_posthog_script');


add_action('admin_head', function () {
    echo '<style>
        .notice { display: none !important; }
    </style>';
});

?>