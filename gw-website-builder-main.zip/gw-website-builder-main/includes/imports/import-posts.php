<?php


function import_posts($file_url) {
    $plugin_dir = ABSPATH . 'wp-content/plugins/gw-website-builder-main'; 
    $uploads_dir = $plugin_dir . '/uploads';

    if (!file_exists($uploads_dir)) {
        mkdir($uploads_dir, 0755, true);
    }

    $local_file_path = $uploads_dir . '/' . basename($file_url);

    if (!download_file($file_url, $local_file_path)) {
        return ['Failed to download the file from: ' . $file_url];
    }

    if (!file_exists($local_file_path)) {
        return ['The XML file does not exist: ' . $local_file_path]; 
    }


    $import_results = [];
    $wp_importer = new GW_Import(); 
    $wp_importer->fetch_attachments = true;

    if (!file_exists($local_file_path)) {
        $import_results[] = 'The file does not exist: ' . $local_file_path;
    } else {
        ob_start();
        $import_result = $wp_importer->import($local_file_path);
        ob_end_clean();
        $import_results[] = is_wp_error($import_result) ? 'Import failed for ' . basename($local_file_path) . ': ' . $import_result->get_error_message() : 'Import successful for ' . basename($local_file_path);
    }

    return $import_results;
}

function import_posts_noimage($file_url) {
    $plugin_dir = ABSPATH . 'wp-content/plugins/gw-website-builder-main'; 
    $uploads_dir = $plugin_dir . '/uploads';

    // Ensure the uploads directory exists
    if (!file_exists($uploads_dir)) {
        mkdir($uploads_dir, 0755, true);
    }

    $local_file_path = $uploads_dir . '/' . basename($file_url);

    if (!download_file($file_url, $local_file_path)) {
        return ['Failed to download the file from: ' . $file_url];
    }

    if (!file_exists($local_file_path)) {
        return ['The XML file does not exist: ' . $local_file_path]; 
    }

    // Download the image and get the new image URL from the media library
    $new_url = get_new_image_url('https://plugin.mywpsite.org/wp-content/uploads/2024/10/Square-img.png');
    
    if (!$new_url) {
        return ['Failed to fetch the new image URL'];
    }

    // Update the XML file with the new image URL
    $result = update_image_urls_in_xml_new($new_url, $local_file_path);

    if (strpos($result, 'XML file updated successfully!') === false && strpos($result, 'No <img> tags') !== false) {
        // Log or track that no img tags were found, but continue the process
        $import_results[] = 'No <img> tags found, but continuing the import process...';
    } else {
        $import_results[] = $result;
    }

    $wp_importer = new GW_Import(); // Make sure GW_Import is defined or included
    $wp_importer->fetch_attachments = true;

    ob_start();
    $import_result = $wp_importer->import($local_file_path);
    ob_end_clean();
    
    $import_results[] = is_wp_error($import_result) ? 'Import failed for ' . basename($local_file_path) . ': ' . $import_result->get_error_message() : 'Import successful for ' . basename($local_file_path);

    return $import_results;
}

function get_new_image_url($image_url) {
    // Download the image and insert it into the WordPress media library
    $attachment_id = download_and_insert_image($image_url);

    // Check if the image was successfully downloaded and inserted
    if ($attachment_id) {
        // Get the URL of the downloaded image
        $image_url = wp_get_attachment_url($attachment_id);
        return $image_url;
    } else {
        return false; // Return false if the image download or insertion failed
    }
}

function download_and_insert_image($image_url) {
    // Download the image to a temporary location
    $tmp_file = download_url($image_url);

    // Check for errors in the download process
    if (is_wp_error($tmp_file)) {
        return false;
    }

    $file = array(
        'name'     => basename($image_url),
        'tmp_name' => $tmp_file,
    );

    // Handle the sideloading (upload to the WordPress uploads folder)
    $attachment_id = media_handle_sideload($file, 0);

    // If error in uploading
    if (is_wp_error($attachment_id)) {
        @unlink($tmp_file); // Remove temp file
        return false;
    }

    // Return the attachment ID for the inserted image
    return $attachment_id;
}

function update_image_urls_in_xml_new($new_url, $local_file_path) {
    if (!file_exists($local_file_path)) {
        return 'XML file not found!';
    }

    // Load the XML content into a DOMDocument
    $dom = new DOMDocument();
    libxml_use_internal_errors(true); // Suppress XML warnings for HTML parsing
    $dom->loadHTMLFile($local_file_path);
    libxml_clear_errors();

    // Get all <img> tags in the XML file
    $images = $dom->getElementsByTagName('img');
    $old_urls = [];
    
    // Define the alt values to look for
    $alt_values_to_find = [
        'banner_image',
        'Emergency Plumbing',
        'Residential Plumbing',
        'Commercial Plumbing',
        'Water Heater',
        'Bathroom and Kitchen',
        'Water Filtration Systems'
    ];

    // Iterate through each <img> tag to find matching alt values or empty alt
    foreach ($images as $img) {
        $alt_value = $img->getAttribute('alt');
        $src_value = $img->getAttribute('src');

        // Check if the alt value matches any in the defined list or is empty
        if (in_array($alt_value, $alt_values_to_find) || empty($alt_value)) {
            $old_urls[] = $src_value;
        }
    }

    // If no matching <img> was found
    if (empty($old_urls)) {
        return 'No <img> tags with specified alt values or empty alt were found!';
    }

    // Get the contents of the XML file as a string
    $xml_content = file_get_contents($local_file_path);

    // Replace each old URL found in the array
    foreach ($old_urls as $old_url) {
        if (strpos($xml_content, $old_url) !== false) {
            $xml_content = str_replace($old_url, $new_url, $xml_content);
        }
    }

    // Save the updated content back to the XML file
    if (file_put_contents($local_file_path, $xml_content)) {
        return 'XML file updated successfully!';
    } else {
        return 'Failed to save the updated XML file!';
    }
}


function update_image_urls_in_xml_new_old($new_url, $local_file_path) {
    if (!file_exists($local_file_path)) {
        return 'XML file not found!';
    }

    // Load the XML content into a DOMDocument
    $dom = new DOMDocument();
    libxml_use_internal_errors(true); // Suppress XML warnings for HTML parsing
    $dom->loadHTMLFile($local_file_path);
    libxml_clear_errors();

    // Get all <img> tags in the XML file
    $images = $dom->getElementsByTagName('img');
    $old_urls = [];
    $found_banner_image = false;

    // Iterate through each <img> tag to find the ones with alt="banner_image" or empty alt
    foreach ($images as $img) {
        $alt_value = $img->getAttribute('alt');
        $src_value = $img->getAttribute('src');

        // If alt="banner_image", collect the src
        if ($alt_value === 'banner_image') {
            $old_urls[] = $src_value;
            $found_banner_image = true; // Mark that we found a "banner_image"
        }
    }

    // If no <img> with alt="banner_image" was found, check for empty alt values
    if (!$found_banner_image) {
        foreach ($images as $img) {
            $alt_value = $img->getAttribute('alt');
            $src_value = $img->getAttribute('src');

            // If alt is empty, collect the src
            if (empty($alt_value)) {
                $old_urls[] = $src_value;
            }
        }

        // If no <img> tags with empty alt were found
        if (empty($old_urls)) {
            return 'No <img> tags with alt="banner_image" or empty alt were found!';
        }
    }

    // Get the contents of the XML file as a string
    $xml_content = file_get_contents($local_file_path);

    // Replace each old URL found in the array
    foreach ($old_urls as $old_url) {
        if (strpos($xml_content, $old_url) !== false) {
            $xml_content = str_replace($old_url, $new_url, $xml_content);
        }
    }

    // Save the updated content back to the XML file
    if (file_put_contents($local_file_path, $xml_content)) {
        return 'XML file updated successfully!';
    } else {
        return 'Failed to save the updated XML file!';
    }
}


?>