<?php
function update_elementor_page_content_directly(WP_REST_Request $request) {
    global $wpdb; 
    //$plugin_dir = plugin_dir_path(__FILE__);
    $plugin_dir = ABSPATH . 'wp-content/plugins/gw-website-builder-main/API/'; 
    $log_dir = $plugin_dir . 'logs'; 
    $log_file_path = $log_dir . '/plugin-log.txt';
    $api_url = $request->get_route();

    // Ensure the logs directory exists
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }

    // Check if Elementor is active
    if (!class_exists('\Elementor\Plugin')) {
        log_message('Elementor is not active.', $log_file_path, 'error', $api_url);
        return new WP_REST_Response(['success' => false, 'message' => 'Elementor is not active'], 500);
    }

    // Clear Elementor cache
    $elementor = \Elementor\Plugin::instance()->files_manager->clear_cache();
    log_message('Elementor files regenerated successfully.', $log_file_path, 'success', $api_url);
    
    // Log the start of the process
    log_message('Processing page content update.', $log_file_path, 'info', $api_url);

    $params = json_decode($request->get_body(), true);
    $page_title = sanitize_text_field($request->get_param('page_name'));
    $page = get_page_by_title($page_title);

    if (!$page) {
        $message = 'Page not found: ' . $page_title;
        log_message($message, $log_file_path, 'error', $api_url);
        return new WP_REST_Response(['success' => false, 'message' => $message], 404);
    }

    $json_content = $wpdb->get_var($wpdb->prepare(
        "SELECT json_content FROM {$wpdb->prefix}generated_content WHERE page_name = %s",
        $page_title
    ));

    if (!$json_content) {
       // Check if JSON content is missing and if the page is "Blog" or "Contact Us"
        if (($page_title === 'Blog' || $page_title === 'Contact Us')) {
            $json_content = $wpdb->get_var($wpdb->prepare(
                "SELECT json_content FROM {$wpdb->prefix}generated_content WHERE page_name = %s",
                'Home'
            ));
        }
    }

    $params = json_decode($json_content);

    $elementor_data = $wpdb->get_var($wpdb->prepare(
        "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_elementor_data'",
        $page->ID
    ));

    if ($elementor_data) {
        $elementor_data = maybe_unserialize($elementor_data); // Ensure it's properly unserialized
        $updated_data = traverse_and_update_content(json_decode($elementor_data, true), $params);
        $encoded_data = wp_json_encode($updated_data);

        $result = $wpdb->update(
            $wpdb->postmeta,
            ['meta_value' => maybe_serialize($encoded_data)], // Ensure it's serialized back properly
            ['post_id' => $page->ID, 'meta_key' => '_elementor_data'],
            ['%s'], // Value format
            ['%d', '%s'] // Where format
        );

        if ($result !== false) {
            // Log successful update
            log_message('Page content updated successfully for page: ' . $page_title, $log_file_path, 'success', $api_url);

            // Try to regenerate CSS
            $css_regeneration_successful = true;
            log_message('CSS regeneration successful for page: ' . $page_title, $log_file_path, 'success', $api_url);
        } else {
            $message = 'Failed to update content for page: ' . $page_title;
            log_message($message, $log_file_path, 'error', $api_url);
            return new WP_REST_Response(['success' => false, 'message' => $message], 500);
        }
    } else {
        $message = 'No Elementor data found for page: ' . $page_title;
        log_message($message, $log_file_path, 'error', $api_url);
        return new WP_REST_Response(['success' => false, 'message' => $message], 404);
    }

    return new WP_REST_Response(['success' => true, 'message' => 'Content updated and CSS regenerated', 'css_regeneration' => $css_regeneration_successful], 200);
}

// function traverse_and_update_content($elementor_data, $replacements) {
//     array_walk_recursive($elementor_data, function (&$item, $key) use ($replacements) {
//         if (is_string($item)) {
//             foreach ($replacements as $search => $replace) {
//                 if (strpos($item, $search) !== false) {
//                     $search = str_replace("\u2019", "'", $search);
//                     $item = str_replace($search, $replace, $item);
//                 }
//             }
//         }
//     });
//     return $elementor_data;
// }

function traverse_and_update_content($elementor_data, $replacements) {
	// Check if $elementor_data is an array
    if (!is_array($elementor_data)) {
        return $elementor_data; // Return as-is or handle accordingly
    }
    array_walk_recursive($elementor_data, function (&$item, $key) use ($replacements) {
        if (is_string($item)) {
            // Replace specific characters in $item
            $item = str_replace("\u2019", "'", $item);
            $item = str_replace('!', '', $item);
            //$item = str_replace('&', 'and', $item);
			$item = str_replace('&amp;', 'and', $item);
			$item = str_replace(["&#39;", "&apos;"], "", $item);
			$item = str_replace("’", "", $item);
			$item = str_replace("'", "", $item);
			$item = str_replace('"', "", $item);
			$item = str_replace('“', "", $item);

            foreach ($replacements as $search => $replace) {
                // Replace specific characters in $search as well
                $search = str_replace("\u2019", "'", $search); // Replace \u2019 with a single quote in $search
                $search = str_replace('!', '', $search); 
				$search = str_replace("&", "and", $search); 
				$search = str_replace("&amp;", "and", $search);
				$search = str_replace(["&#39;", "&apos;"], "", $search);
				$search = str_replace("’", "", $search);
				$search = str_replace("'", "", $search);
				$search = str_replace('“', "", $search);
				$search = str_replace('"', "", $search);
				
                if (strpos($item, $search) !== false) {
                    $item = str_replace($search, $replace, $item);
                }
            }
        }
    });

    return $elementor_data;
}



?>