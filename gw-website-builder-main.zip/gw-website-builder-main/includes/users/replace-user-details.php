<?php 

function update_user_details_data(WP_REST_Request $request) {
    global $wpdb;
    $plugin_dir = ABSPATH . 'wp-content/plugins/gw-website-builder-main/API/'; 
    //$plugin_dir = plugin_dir_path(__FILE__);
    $log_dir = $plugin_dir . 'logs'; 
    $log_file_path = $log_dir . '/plugin-log.txt';
    $api_url = $request->get_route();

    // Ensure the logs directory exists
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }
    
    // Check if Elementor is active
    if (!class_exists('\Elementor\Plugin')) {
        log_message('Elementor is not active.', $log_file_path, 'error', $api_url);
        return new WP_REST_Response(['success' => false, 'message' => 'Elementor is not active'], 500);
    }

    // Clear Elementor cache
    $elementor = \Elementor\Plugin::instance()->files_manager->clear_cache();
    log_message('Elementor files regenerated successfully.', $log_file_path, 'success', $api_url);
    

    log_message('Starting to update user details data.', $log_file_path, 'info', $api_url);

    $post_names = ['Footer', 'Contact Us'];

    $table_name = $wpdb->prefix . 'gw_user_form_details';
    $results = $wpdb->get_results("SELECT * FROM $table_name", ARRAY_A);
    
    $dynamic_contactform = null;
    $first_sentence = null;
  
    // Check for contact form data
    if (!empty($results)) {
      
        foreach ($results as $row) {
           
            if(!empty($row['description1'])){
                $description1 =  $row['description1'];
                $first_sentence = explode('.', $description1)[0] . '.'; 
            }
            if (!empty($row['contactform'])) {
                $contactform_data = json_decode($row['contactform'], true);
                
                if (!empty($contactform_data)) {
                    $dynamic_contactform = $contactform_data; // Assign dynamic contact form data
                    log_message("Contact form data found: " . json_encode($dynamic_contactform), $log_file_path, 'info', $api_url);
                    break;
                }
            }
        }
    } else {
        log_message('No contact form data found in the table.', $log_file_path, 'info', $api_url);
    }
    
    if ($first_sentence) {
        $static_sentence = 'Capturing Your Audiences Interest The initial impression your blog post makes is.';
        $updated_description = [$static_sentence => $first_sentence];

        foreach ($post_names as $post_name) {
            log_message("Processing post with name: {$post_name}", $log_file_path, 'info', $api_url);

            $query = $wpdb->prepare("SELECT post_id FROM {$wpdb->prefix}imported_posts WHERE page_name = %s LIMIT 1", $post_name);
            $post_id = $wpdb->get_var($query);

            if (!$post_id) {
                $message = "No post found with the specified name: {$post_name}";
                log_message($message, $log_file_path, 'error', $api_url);
                continue;
            }

            log_message("Post found: ID = {$post_id}", $log_file_path, 'info', $api_url);

            $elementor_data = get_post_meta($post_id, '_elementor_data', true);
            if (!$elementor_data) {
                $message = "Failed to retrieve Elementor description data for post name: {$post_name}";
                log_message($message, $log_file_path, 'error', $api_url);
                continue;
            }

            log_message("Elementor description data retrieved for post ID: {$post_id}", $log_file_path, 'info', $api_url);

            $elementor_data = json_decode($elementor_data, true);
            $updated_data = traverse_and_update_content($elementor_data, $updated_description);

            $update_result = update_post_meta($post_id, '_elementor_data', json_encode($updated_data));
            if ($update_result === false) {
                $message = "Failed to update the Elementor description data for post ID: {$post_id}";
                log_message($message, $log_file_path, 'error', $api_url);
                continue;
            }

            log_message("Elementor data description updated successfully for post ID: {$post_id}", $log_file_path, 'success', $api_url);
        }
    }

    if ($dynamic_contactform) {

        $address = isset($dynamic_contactform['address']) ? $dynamic_contactform['address'] : '';
        $email = isset($dynamic_contactform['email']) ? $dynamic_contactform['email'] : '';
        $phone = isset($dynamic_contactform['phone']) ? $dynamic_contactform['phone'] : '';

        $new_address_key = "2360 Hood Avenue, San Diego, CA, 92123";
        $new_email_key = "contact@example.com";
        $new_phone_key = "202-555-0188";

        $updated_contactform = [];

        foreach ($dynamic_contactform as $key => $value) {
            if ($key === 'address') {
                $updated_contactform[$new_address_key] = $value;  // Replace the key for address
            } elseif ($key === 'email') {
                $updated_contactform[$new_email_key] = $value;    // Replace the key for email
            } elseif ($key === 'phoneNumber') {
                $updated_contactform[$new_phone_key] = $value;    // Replace the key for phone
            } else {
                $updated_contactform[$key] = $value;
            }
        }

    

        foreach ($post_names as $post_name) {
            log_message("Processing post with name: {$post_name}", $log_file_path, 'info', $api_url);

            $query = $wpdb->prepare("SELECT post_id FROM {$wpdb->prefix}imported_posts WHERE page_name = %s LIMIT 1", $post_name);
            $post_id = $wpdb->get_var($query);

            if (!$post_id) {
                $message = "No post found with the specified name: {$post_name}";
                log_message($message, $log_file_path, 'error', $api_url);
                continue;
            }

            log_message("Post found: ID = {$post_id}", $log_file_path, 'info', $api_url);

            $elementor_data = get_post_meta($post_id, '_elementor_data', true);
            if (!$elementor_data) {
                $message = "Failed to retrieve Elementor data for post name: {$post_name}";
                log_message($message, $log_file_path, 'error', $api_url);
                continue;
            }

            log_message("Elementor data retrieved for post ID: {$post_id}", $log_file_path, 'info', $api_url);

            $elementor_data = json_decode($elementor_data, true);

            log_message('Starting to update Elementor content.', $log_file_path, 'info', $api_url);

            $updated_data = traverse_and_update_content($elementor_data, $updated_contactform);

            $update_result = update_post_meta($post_id, '_elementor_data', json_encode($updated_data));

            if ($update_result === false) {
                $message = "Failed to update the Elementor data for post ID: {$post_id}";
                log_message($message, $log_file_path, 'error', $api_url);
                continue;
            }

            log_message("Elementor data updated successfully for post ID: {$post_id}", $log_file_path, 'success', $api_url);
        }

        return new WP_REST_Response(['success' => true, 'message' => 'Post data updated successfully for footer and contact-us'], 200);
    } else {
        return new WP_REST_Response(['success' => false, 'message' => 'No valid contact form data found'], 404);
    }
}



?>