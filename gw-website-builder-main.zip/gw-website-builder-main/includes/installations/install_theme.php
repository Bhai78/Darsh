<?php 

function install_theme() {
    $theme_slug = 'astra'; // Theme slug to install
    $theme_path = WP_CONTENT_DIR . '/themes/' . $theme_slug;

    // Install the theme if it's not already installed
    if (!file_exists($theme_path)) {
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php'; // Include the upgrader class
        $upgrader = new Theme_Upgrader(new WP_Ajax_Upgrader_Skin());
        $result = $upgrader->install('https://downloads.wordpress.org/theme/' . $theme_slug . '.zip');
        
        // Check for errors during installation
        if (is_wp_error($result)) {
            return ['success' => false, 'error' => $result->get_error_message()];
        }
    }

    // Activate the theme if it's not already active
    $current_theme = wp_get_theme();
    if ($current_theme->get_template() !== $theme_slug) {
        $activate = switch_theme($theme_slug);
        if (is_wp_error($activate)) {
            return ['success' => false, 'error' => $activate->get_error_message()];
        }
    }

    // Update Astra theme settings
    $astra_settings = get_option('astra-settings', array());

    // Add or update the required settings
    $astra_settings['single-page-ast-content-layout'] = 'full-width-container';
    $astra_settings['single-post-ast-content-layout'] = 'full-width-container';

    // Update the Astra settings option
    update_option('astra-settings', $astra_settings);

    return ['success' => true, 'message' => 'Astra theme installed, activated, and settings updated successfully.'];
}



?>